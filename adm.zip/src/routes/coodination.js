export const goToCadastro = (history) => {
    history.push("/cadastro")
}

export const goToInformation = (history) => {
    history.push("/informacoesUser")
}