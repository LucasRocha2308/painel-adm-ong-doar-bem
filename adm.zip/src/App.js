import AppRoutes from "../src/routes/routes";

function App() {
  return (
  <>
    <AppRoutes />
  </>
  )
}

export default App;

