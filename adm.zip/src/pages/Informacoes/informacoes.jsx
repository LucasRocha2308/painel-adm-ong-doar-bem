import React from 'react'
import './styled.scss'
const InformacoesUsuario = () => {

    const username = localStorage.getItem("userData");
    const userData = JSON.parse(username)


    return (
        <div>
        </div>
    )
        
  }

export default InformacoesUsuario